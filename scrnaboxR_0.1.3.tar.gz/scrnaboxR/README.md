# scrnaboxR
A supplementary codes for scrnabox pipeline.   

## Overview
This library includes some functions that can be used to achieve the computation to analysis the scRNA. 

## Installation
``` r
devtools::install_github("neurobioinfo/scrnabox/scrnaboxR")
```

## Usage
- Annotation

## Getting help
